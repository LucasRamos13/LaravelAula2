<?php

use Illuminate\Database\Seeder;
use App\Mensagem;

class MensagensTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Mensagem::create([
            'titulo' => 'Os contos de Jorge',
            'autor' => 'Contos contados pelo contador',
            'texto' => 'poético'
        ]);

        Mensagem::create([
            'titulo' => 'As aventuras de Jorge',
            'autor' => 'O Jorge',
            'texto' => 'Premiado pelo globo de tungstênio por melhor trilha sonora'
        ]);
    }
}
