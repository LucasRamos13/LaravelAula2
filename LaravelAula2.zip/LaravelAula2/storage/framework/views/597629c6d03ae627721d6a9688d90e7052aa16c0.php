<h1></h1>
<hr>
<h3><b>ID:</b> <?php echo e($atividade->id); ?><h3>
<h3><b>Título:</b> <?php echo e($atividade->title); ?><h3>
<h3><b>Data:</b> <?php echo e($atividade->scheduledto); ?><h3>
<h3><b>Criado em:</b> <?php echo e($atividade->created_at); ?><h3>
<h3><b>Atualizado em:</b> <?php echo e($atividade->updated_at); ?><h3>