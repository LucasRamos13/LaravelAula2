<h1>Lista de mensagens</h1>
<hr>
<?php $__currentLoopData = $mensagens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mensagem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<h3><?php echo e($mensagem->titulo); ?></h3>
	<p><?php echo e($mensagem->texto); ?></p>
	<p><?php echo e($mensagem->autor); ?></p>
	<p><?php echo e($mensagem->created_at); ?></p>
	<br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


