<h1></h1>
<hr>
<h3><b>ID:</b> {{$atividade->id}}<h3>
<h3><b>Título:</b> {{$atividade->title}}<h3>
<h3><b>Data:</b> {{$atividade->scheduledto}}<h3>
<h3><b>Criado em:</b> {{$atividade->created_at}}<h3>
<h3><b>Atualizado em:</b> {{$atividade->updated_at}}<h3>