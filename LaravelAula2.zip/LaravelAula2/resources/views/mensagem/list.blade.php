<h1>Lista de mensagens</h1>
<hr>
@foreach($mensagens as $mensagem)
	<h3>{{$mensagem->titulo}}</h3>
	<p>{{$mensagem->texto}}</p>
	<p>{{$mensagem->autor}}</p>
	<p>{{$mensagem->created_at}}</p>
	<br>
@endforeach


